#ifndef _TELNETPRINT_H_
#define _TELNETPRINT_H_

#include "NetTypes.h"

extern NetServer TelnetPrint;

#endif
