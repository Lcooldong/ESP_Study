#pragma once

#define portTICK_PERIOD_MS 1000

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

class Main final
{
public:
    esp_err_t setup(void);
    void loop(void);
};